

if (typeof tophead === 'undefined') { var tophead = true; }
if (typeof lefthead === 'undefined') { var lefthead = true; }
if (typeof color === 'undefined') { var color = '#ffffff'; }
if (typeof data === 'undefined') { var data = ['?']; }

$(function () {
    for (var y = 0; y < data.length; y++) {
        var dat = data[y];
        var row = $('<tr>');
        for (var x = 0; x < dat.length; x++) {
            var val = dat[x];
            row.append($('<td>' + val + '</td>').toggleClass('bold', (y == 0 && tophead) || (x == 0 && lefthead)));
        }
        $('#table').append(row);
    }
    $('#table td').css({
        'color': color,
        'border-color': color
    });
})
