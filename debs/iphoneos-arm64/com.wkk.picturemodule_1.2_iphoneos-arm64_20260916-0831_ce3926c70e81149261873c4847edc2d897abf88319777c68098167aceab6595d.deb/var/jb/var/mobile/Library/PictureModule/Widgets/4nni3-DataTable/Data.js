var data = [
    ["", "Mon", "Tue", "Web", "Thu", "Fri"],
    ["1", "Math", "Groups", "Groups", "Groups", "Groups"],
    ["2", "Art", "PE", "Music", "Math", "PE"],
    ["3", "Science", "Tech", "Biologie", "Physics", "Biologie"],
    ["4", "Chemistry", "Art", "Math", "Math", "English"],
    ["5", "PE", "Physics", "English", "Math", "Biologie"],
    ["6", "Math", "Music", "", "Math", "Art"]
];
